import java.util.Scanner;

class Rectangle_Operations {
    int lgth; 
    int brth; 
    int area; 
   
    public Rectangle_Operations()
    {
    	lgth = 0;
    	brth= 0;
    }
    
    void input() 
    {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter the length of rectangle: ");
        lgth = in.nextInt();
        System.out.print("Enter the breadth of rectangle: ");
        brth = in.nextInt();
    }

    void calculate() 
    {
        area = lgth * brth;       
    }

    void display() 
    {
        System.out.println("Area of Rectangle = " + area);
    }

    public static void main(String args[])
    {
    	System.out.println("Test1:");
        Rectangle_Operations obj1 = new Rectangle_Operations();
        obj1.input();
        obj1.calculate();
        obj1.display();
        System.out.println("--------------------------");
        System.out.println("Test2:");
        Rectangle_Operations obj2 = new Rectangle_Operations();
        obj2.input();
        obj2.calculate();
        obj2.display();
        System.out.println("--------------------------");
        System.out.println("Test3:");
        Rectangle_Operations obj3 = new Rectangle_Operations();
        obj3.input();
        obj3.calculate();
        obj3.display();
        System.out.println("--------------------------");
        System.out.println("Test4:");
        Rectangle_Operations obj4 = new Rectangle_Operations();
        obj4.input();
        obj4.calculate();
        obj4.display();
        System.out.println("--------------------------");
        System.out.println("Test5:");
        Rectangle_Operations obj5 = new Rectangle_Operations();
        obj5.input();
        obj5.calculate();
        obj5.display();
    }
}