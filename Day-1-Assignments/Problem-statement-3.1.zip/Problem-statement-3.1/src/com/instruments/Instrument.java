package com.instruments;

public abstract class Instrument {
	public abstract void play();
}
