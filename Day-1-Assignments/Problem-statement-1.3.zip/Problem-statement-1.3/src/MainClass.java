public class MainClass {
	public void createBooks() 
	{
		Book bks[] = new Book[2];
		
	      bks[0] = new Book("Java Programing ", 350.50);
	      bks[1] = new Book("Let Us C", 200.00);
	      
	      for(int i = 0; i<bks.length; i++) 
	      {
		         bks[i].display();
		         System.out.println(" ");
	      }
	 }
	
	public void showBooks()
	{
		  	createBooks();
	}
	
public static void main(String args[])  
{
	MainClass c1 = new MainClass();  
		c1.showBooks();
 }
	   
}

