import java.util.Scanner;

class Modified_RectangleOperations
{
    int length; 
    int width; 
    int area; 
    int perimeter;
    
    public int getLength()
    {
		return length;
	}

	public void setLength(int length) 
	{
		this.length = length;
	}

	public int getWidth()
	{
		return width;
	}

	public void setWidth(int width) 
	{
		this.width = width;
	}
	
public Modified_RectangleOperations()
    {
    	length = 1;
    	width= 1;
    }

    void input() 
    {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter the length of rectangle: ");
        length = in.nextInt();
        System.out.print("Enter the width of rectangle: ");
        width = in.nextInt();
    }
    
 void  areaofRectangle()
    {
        area = length * width;   
    }
 
 void  perimeterRectangle()
    {
    	 perimeter = 2*(length + width);
    }

 void display()
    {
    	if(length>0 && length<20)
        {
        System.out.println("Area of Rectangle = " + area);
        System.out.println("Parameter of Rectangle = " +perimeter);}
       }

public static void main(String args[]) 
{
	System.out.println("Test1:");    	
    	Modified_RectangleOperations obj1 = new Modified_RectangleOperations();
        obj1.input();
        obj1.areaofRectangle();
        obj1.perimeterRectangle();
        obj1.display();
        System.out.println("---------------------");
    System.out.println("Test2:");
        Modified_RectangleOperations obj2 = new Modified_RectangleOperations();
        obj2.input();
        obj2.areaofRectangle();
        obj2.perimeterRectangle();
        obj2.display();
        System.out.println("---------------------");
    System.out.println("Test3:");
        Modified_RectangleOperations obj3 = new Modified_RectangleOperations();
        obj3.input();
        obj3.areaofRectangle();
        obj3.perimeterRectangle();
        obj3.display();
        System.out.println("---------------------");
    System.out.println("Test4:");
        Modified_RectangleOperations obj4 = new Modified_RectangleOperations();
        obj4.input();
        obj4.areaofRectangle();
        obj4.perimeterRectangle();
        obj4.display();
    System.out.println("Test5:");
        System.out.println("---------------------");
        Modified_RectangleOperations obj5 = new Modified_RectangleOperations();
        obj5.input();
        obj5.areaofRectangle();
        obj5.perimeterRectangle();
        obj5.display();
    	
    }
}