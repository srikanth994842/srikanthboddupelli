package com.medicines;

public class Medicine
{
public void displayLabel()
{
	System.out.println("Company : Apollo Pharmacy");
	System.out.println("Address : Warangal");}}

class Tablet extends Medicine{
	 
public void displayLabel()
{
	System.out.println("Store it in a cool-dry place");
	}
}
	
class Syrup extends Medicine
{
	public void displayLabel()
	{
		System.out.println("Consumption as directed by the Physician");
		}
	}
class Ointment extends Medicine{
	public void displayLabel()
{
	System.out.println("For external use only");
	}
}